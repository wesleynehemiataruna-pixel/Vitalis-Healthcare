"use client"

import { useState } from "react"
import { ArrowRight, Lock, Key, CheckCircle, Copy, Shield, Heart, Database } from "lucide-react"

// --- Encryption Utility Functions ---
const EncryptionUtils = {
  encrypt: (text, key) => {
    const keyHash = Array.from(key)
      .reduce((acc, char) => (acc << 5) - acc + char.charCodeAt(0), 0)
      .toString()
      .padEnd(32, "0")
    let encrypted = ""
    for (let i = 0; i < text.length; i++) {
      encrypted += String.fromCharCode(text.charCodeAt(i) ^ keyHash.charCodeAt(i % keyHash.length))
    }
    return btoa(encrypted)
  },
  decrypt: (encoded, key) => {
    try {
      const encrypted = atob(encoded)
      const keyHash = Array.from(key)
        .reduce((acc, char) => (acc << 5) - acc + char.charCodeAt(0), 0)
        .toString()
        .padEnd(32, "0")
      let decrypted = ""
      for (let i = 0; i < encrypted.length; i++) {
        decrypted += String.fromCharCode(encrypted.charCodeAt(i) ^ keyHash.charCodeAt(i % keyHash.length))
      }
      return decrypted
    } catch (e) {
      return null
    }
  },
}

// Custom Button Component
const Button = ({ children, onClick, variant = "default", size = "default", className = "", disabled = false }) => {
  const baseStyle =
    "inline-flex items-center justify-center rounded-lg font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:opacity-50 disabled:pointer-events-none shadow-md"
  let sizeStyle = ""
  let variantStyle = ""

  switch (size) {
    case "lg":
      sizeStyle = "h-12 px-6 text-lg"
      break
    case "sm":
      sizeStyle = "h-8 px-3 text-sm"
      break
    case "icon":
      sizeStyle = "h-10 w-10"
      break
    default:
      sizeStyle = "h-10 px-4 py-2"
  }

  switch (variant) {
    case "outline":
      variantStyle = "border border-input bg-background hover:bg-primary/10 text-foreground"
      break
    case "secondary":
      variantStyle = "bg-secondary text-secondary-foreground hover:bg-secondary/90"
      break
    case "ghost":
      variantStyle = "hover:bg-primary/10 text-primary"
      break
    case "link":
      variantStyle = "text-primary underline-offset-4 hover:underline"
      break
    default:
      variantStyle = "bg-primary text-primary-foreground hover:bg-primary/90"
  }

  return (
    <button onClick={onClick} className={`${baseStyle} ${sizeStyle} ${variantStyle} ${className}`} disabled={disabled}>
      {children}
    </button>
  )
}

// Step Indicator
const StepIndicator = ({ step, currentStep, title }) => {
  const isActive = step === currentStep
  const isComplete = step < currentStep
  return (
    <div className="flex items-center space-x-2">
      <div
        className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm transition-all duration-300
                    ${isComplete ? "bg-primary text-primary-foreground" : isActive ? "bg-accent text-primary-foreground shadow-lg" : "bg-secondary text-muted-foreground border border-input"}`}
      >
        {isComplete ? <CheckCircle className="w-4 h-4" /> : step}
      </div>
      <span className={`font-medium text-sm ${isActive ? "text-foreground" : "text-muted-foreground"}`}>{title}</span>
    </div>
  )
}

const KeyGenerationStep = ({ onNext }) => {
  const [mnemonic, setMnemonic] = useState("")
  const [address, setAddress] = useState("")
  const [copied, setCopied] = useState(false)
  const [confirmed, setConfirmed] = useState(false)
  const [isGenerating, setIsGenerating] = useState(false)
  const [isCreating, setIsCreating] = useState(false)
  const [creationError, setCreationError] = useState(null)

  const generateWallet = () => {
    setIsGenerating(true)
    setTimeout(() => {
      const words =
        "abandon ability able about above absent absorb abstract academy accept access accident account achieve acid acoustic acquired across act action actor actuality actual ad ade advanced advantage adventure advertise advice aerobic affair afford afraid after again against agency agent agree ahead aim air airport aisle alarm album alcohol alert algebra algorithm alike alive all alley allow almost alone alpha already also alter always amateur amazing ambiguous among amount amused analyst anchor ancient and android angel anger angle angry animal ankle announce annual another answer antenna anti antique anxiety any apart apology appear apple apply appoint appreciate approach appropriate approval approve april apt arbitrary arbitrate arc arch are area arena argue aria arise arm armed armor army around arrange array arrest arrival arrive arrow arson art artefact artist arts artwork as asay ascend ash ashamed aside ask aspect aspire assail assault assay assess asset assign assist assume assonance assort assure astonish astound astray astrology astronomy astrophysics at ate atheism athlete athletic atlas atom atone attach attack attain attempt attend attention attentive attitude attorney attract auction auction auction auction auction auction auction".split(
          " ",
        )
      const selectedWords = Array.from({ length: 12 }, () => words[Math.floor(Math.random() * words.length)]).join(" ")
      const mockAddress = "0x" + Array.from({ length: 40 }, () => Math.floor(Math.random() * 16).toString(16)).join("")

      setMnemonic(selectedWords)
      setAddress(mockAddress)
      setIsGenerating(false)
    }, 500)
  }

  const handleCopy = () => {
    if (mnemonic) {
      navigator.clipboard.writeText(mnemonic)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const handleSaveWallet = async () => {
    if (!confirmed) return

    setIsCreating(true)
    setCreationError(null)

    try {
      console.log("[v0] Saving wallet to database")

      const response = await fetch("/api/wallet/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          walletAddress: address,
          publicKey: mnemonic.split(" ")[0],
          mnemonicHash: mnemonic.split(" ").slice(0, 4).join("-"),
        }),
      })

      const result = await response.json()
      console.log("[v0] Wallet creation response:", response.status, result)

      if (!response.ok) {
        throw new Error(result.error || "Failed to create wallet")
      }

      console.log("[v0] Wallet saved successfully with userId:", result.userId)
      onNext({ mnemonic, address, userId: result.userId })
    } catch (error) {
      console.error("[v0] Wallet save error:", error)
      setCreationError(error.message)
    } finally {
      setIsCreating(false)
    }
  }

  return (
    <div className="space-y-6">
      <div className="text-center p-6 space-y-4">
        <div className="flex justify-center mb-4">
          <Heart className="w-12 h-12 text-primary" />
        </div>
        <p className="text-lg text-muted-foreground">
          Create your secure healthcare DID wallet. This generates your unique digital identity for medical data
          control.
        </p>
        <Button size="lg" onClick={generateWallet} disabled={isGenerating} className="gap-2">
          {isGenerating ? "Generating..." : "Generate My Healthcare DID"}
          <Key className="w-5 h-5" />
        </Button>
      </div>

      <div className="p-4 bg-red-100 border border-red-400 text-red-800 rounded-lg shadow-sm">
        <h3 className="font-bold mb-1 flex items-center gap-2 text-red-800">
          <Lock className="w-5 h-5" /> CRITICAL SECURITY WARNING
        </h3>
        <p className="text-sm">
          This **12-word phrase is your master key** to all encrypted health data. We will **NEVER** store it. If you
          lose it, you lose access forever.
        </p>
      </div>

      <div className="p-6 border border-input rounded-lg bg-secondary/20">
        <p className="font-semibold mb-2">Your Wallet Recovery Phrase:</p>
        <div className="bg-white p-3 rounded-md border border-dashed border-primary/50 font-mono text-sm break-words flex justify-between items-center">
          <span className="text-foreground">{mnemonic}</span>
          <Button variant="ghost" size="icon" onClick={handleCopy} className="ml-4 flex-shrink-0">
            {copied ? <CheckCircle className="w-4 h-4 text-primary" /> : <Copy className="w-4 h-4" />}
          </Button>
        </div>
        <p className="mt-2 text-xs text-muted-foreground">
          Your DID:{" "}
          <span className="font-mono text-primary">
            {address.substring(0, 8)}...{address.substring(address.length - 6)}
          </span>
        </p>
      </div>

      <div className="flex items-start space-x-3">
        <input
          type="checkbox"
          id="backup_confirm"
          checked={confirmed}
          onChange={(e) => setConfirmed(e.target.checked)}
          className="mt-1 h-5 w-5 rounded border-input text-primary focus:ring-primary/80"
        />
        <label htmlFor="backup_confirm" className="text-sm font-medium leading-6">
          I have safely backed up my recovery phrase in a secure location.
        </label>
      </div>

      {creationError && (
        <div className="p-3 bg-red-50 border border-red-200 rounded text-sm text-red-900">
          Error creating wallet: {creationError}
        </div>
      )}

      <div className="flex justify-end">
        <Button size="lg" onClick={handleSaveWallet} disabled={!confirmed || isCreating} className="gap-2">
          {isCreating ? "Creating Wallet..." : "Wallet Created (Next)"}
          <ArrowRight className="w-4 h-4" />
        </Button>
      </div>
    </div>
  )
}

const DataInputStep = ({ onNext, initialData }) => {
  const [formData, setFormData] = useState({
    fullName: "",
    dob: "",
    bloodType: "",
    allergies: "",
    conditions: "",
    medications: "",
    email: "",
    phone: "",
    emergencyContact: "",
    ...initialData,
  })
  const [isEncrypting, setIsEncrypting] = useState(false)

  const handleChange = (e) => {
    const { id, value } = e.target
    setFormData((prev) => ({ ...prev, [id]: value }))
  }

  const handleNext = async () => {
    setIsEncrypting(true)

    const healthDataString = `${formData.fullName}|${formData.dob}|${formData.bloodType}|${formData.allergies}|${formData.conditions}|${formData.medications}`
    const encryptionKey = initialData.address || "default-key"
    const encryptedHealthData = EncryptionUtils.encrypt(healthDataString, encryptionKey)

    await new Promise((resolve) => setTimeout(resolve, 1500))

    setIsEncrypting(false)
    onNext({ ...formData, encryptedHealthData })
  }

  const isFormValid = formData.fullName && formData.dob && formData.bloodType && formData.email

  return (
    <div className="space-y-6">
      <p className="text-muted-foreground">
        Enter your health information. All data will be **encrypted** and stored securely in your wallet.
      </p>

      <div className="bg-blue-50 border border-blue-200 p-4 rounded-lg flex gap-3">
        <Shield className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
        <p className="text-sm text-blue-900">
          Data Encryption: All health records are encrypted with your DID key and never transmitted unencrypted.
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <InputGroup id="fullName" label="Full Legal Name" value={formData.fullName} onChange={handleChange} />
        <InputGroup id="dob" label="Date of Birth" type="date" value={formData.dob} onChange={handleChange} />

        <SelectGroup id="bloodType" label="Blood Type" value={formData.bloodType} onChange={handleChange}>
          <option value="">Select...</option>
          <option value="O+">O+</option>
          <option value="O-">O-</option>
          <option value="A+">A+</option>
          <option value="A-">A-</option>
          <option value="B+">B+</option>
          <option value="B-">B-</option>
          <option value="AB+">AB+</option>
          <option value="AB-">AB-</option>
        </SelectGroup>

        <InputGroup
          id="allergies"
          label="Allergies (comma-separated)"
          value={formData.allergies}
          onChange={handleChange}
          helpText="e.g., Penicillin, Peanuts"
        />
        <InputGroup
          id="conditions"
          label="Medical Conditions"
          value={formData.conditions}
          onChange={handleChange}
          helpText="e.g., Diabetes, Asthma"
        />
        <InputGroup
          id="medications"
          label="Current Medications"
          value={formData.medications}
          onChange={handleChange}
          helpText="e.g., Metformin 500mg, Albuterol"
        />

        <InputGroup id="email" label="Email Address" type="email" value={formData.email} onChange={handleChange} />
        <InputGroup id="phone" label="Phone Number" type="tel" value={formData.phone} onChange={handleChange} />
        <InputGroup
          id="emergencyContact"
          label="Emergency Contact"
          value={formData.emergencyContact}
          onChange={handleChange}
        />
      </div>

      <div className="flex justify-end">
        <Button size="lg" onClick={handleNext} disabled={!isFormValid || isEncrypting} className="gap-2">
          {isEncrypting ? "Encrypting Health Data..." : "Encrypt & Next"}
          <ArrowRight className="w-4 h-4" />
        </Button>
      </div>
    </div>
  )
}

const DataEncryptionStep = ({ userData }) => {
  const [isStoring, setIsStoring] = useState(false)
  const [storageStatus, setStorageStatus] = useState(null)
  const [showEncrypted, setShowEncrypted] = useState(false)
  const [storageError, setStorageError] = useState(null)

  const handleStoreData = async () => {
    setIsStoring(true)
    setStorageError(null)

    try {
      console.log("[v0] Starting health data storage")

      const response = await fetch("/api/wallet/store-health-data", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          bloodType: userData.bloodType,
          allergies: userData.allergies,
          medicalConditions: userData.conditions,
          currentMedications: userData.medications,
          emergencyContact: userData.emergencyContact,
          encryptedData: userData.encryptedHealthData,
          dataHash: userData.encryptedHealthData.substring(0, 32) + "...",
          didAddress: userData.address,
          fullName: userData.fullName,
          dateOfBirth: userData.dob,
        }),
      })

      const result = await response.json()
      console.log("[v0] API response:", response.status, result)

      if (!response.ok) {
        console.log("[v0] Storage failed:", result)
        throw new Error(result.error || `HTTP ${response.status}: Failed to store health data`)
      }

      console.log("[v0] Storage successful:", result.recordId)
      const storageId = result.recordId || `HEALTH-RECORD-${Math.random().toString(36).substring(2, 9).toUpperCase()}`
      setStorageStatus(storageId)
    } catch (error) {
      console.error("[v0] Storage error details:", error)
      setStorageError(error.message)
    } finally {
      setIsStoring(false)
    }
  }

  return (
    <div className="space-y-6">
      <p className="text-muted-foreground text-lg">
        Your encrypted health data is ready to be stored in your blockchain wallet. Only you can decrypt this data using
        your wallet.
      </p>

      <div className="p-5 border border-primary/30 rounded-lg bg-secondary/20 space-y-3">
        <div className="flex items-center gap-2">
          <Database className="w-5 h-5 text-primary" />
          <p className="text-sm font-semibold">
            DID Address: <span className="font-mono text-primary">{userData.address.substring(0, 12)}...</span>
          </p>
        </div>
        <p className="text-sm font-semibold">
          Encryption Status: <span className="text-green-600">✓ Encrypted</span>
        </p>
        <p className="text-sm text-muted-foreground">
          Data Size: {Math.round((userData.encryptedHealthData?.length || 0) / 1024)}KB
        </p>
      </div>

      <div className="p-5 bg-card border border-input rounded-lg space-y-4">
        <div className="flex items-center gap-3 mb-4">
          <Shield className="w-6 h-6 text-accent" />
          <h3 className="text-xl font-bold">Store Health Data in Wallet</h3>
        </div>

        {storageError && (
          <div className="p-3 bg-red-50 border border-red-200 rounded text-sm text-red-900">Error: {storageError}</div>
        )}

        {storageStatus ? (
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-primary">
              <CheckCircle className="w-5 h-5" />
              <p className="font-medium">Health Record Stored! ID: {storageStatus}</p>
            </div>
            <div className="p-3 bg-green-50 border border-green-200 rounded text-sm text-green-900">
              Your encrypted health data is now stored in your blockchain wallet and only accessible with your recovery
              phrase.
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            <p className="text-sm text-muted-foreground">
              This securely stores your encrypted health records in the blockchain database, linked to your DID wallet.
            </p>
            <div className="p-3 bg-blue-50 border border-blue-200 rounded text-sm text-blue-900 flex gap-2">
              <Lock className="w-4 h-4 flex-shrink-0 mt-0.5" />
              <span>End-to-end encryption ensures only you can access your health data.</span>
            </div>
          </div>
        )}

        {showEncrypted && (
          <div className="mt-4 p-3 bg-gray-50 border border-gray-300 rounded font-mono text-xs break-all max-h-32 overflow-y-auto">
            {userData.encryptedHealthData}
          </div>
        )}
      </div>

      <div className="flex justify-between items-center gap-3 flex-wrap">
        {!storageStatus && (
          <Button variant="secondary" size="sm" onClick={() => setShowEncrypted(!showEncrypted)} className="gap-2">
            {showEncrypted ? "Hide" : "View"} Encrypted Data
          </Button>
        )}

        <Button
          size="lg"
          onClick={handleStoreData}
          disabled={isStoring || !!storageStatus}
          className="gap-2 bg-accent hover:bg-accent/90"
        >
          {isStoring ? "Storing in Wallet..." : "Store Encrypted Health Data"}
          {!storageStatus && <ArrowRight className="w-4 h-4" />}
        </Button>

        {storageStatus && (
          <a href="https://vitalisdashboard.vercel.app/" target="_top">
            <Button size="lg" className="gap-2">
              Access Your Wallet
              <ArrowRight className="w-4 h-4" />
            </Button>
          </a>
        )}
      </div>
    </div>
  )
}

// Form Elements
const InputGroup = ({ id, label, type = "text", value, onChange, helpText = "" }) => (
  <div className="space-y-1">
    <label htmlFor={id} className="text-sm font-medium leading-6 text-foreground">
      {label}
    </label>
    <input
      type={type}
      id={id}
      value={value}
      onChange={onChange}
      className="w-full rounded-md border border-input bg-background p-2 text-foreground shadow-sm focus:border-primary focus:ring-primary focus-visible:outline-none"
      required
    />
    {helpText && <p className="text-xs text-muted-foreground italic mt-1">{helpText}</p>}
  </div>
)

const SelectGroup = ({ id, label, value, onChange, children }) => (
  <div className="space-y-1">
    <label htmlFor={id} className="text-sm font-medium leading-6 text-foreground">
      {label}
    </label>
    <select
      id={id}
      value={value}
      onChange={onChange}
      className="w-full rounded-md border border-input bg-background p-2 text-foreground shadow-sm focus:border-primary focus:ring-primary focus-visible:outline-none"
      required
    >
      {children}
    </select>
  </div>
)

// Main App
const steps = [
  { title: "Create DID Wallet", component: KeyGenerationStep },
  { title: "Add Health Data", component: DataInputStep },
  { title: "Encrypt & Store", component: DataEncryptionStep },
]

export default function App() {
  const [currentStep, setCurrentStep] = useState(1)
  const [userData, setUserData] = useState({})

  const handleNext = (data) => {
    setUserData((prev) => ({ ...prev, ...data }))
    setCurrentStep((prev) => prev + 1)
  }

  const CurrentStepComponent = steps[currentStep - 1]?.component

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-secondary/30 to-background p-4 sm:p-8 flex items-center justify-center bg-background">
      <div className="w-full max-w-4xl bg-card rounded-2xl shadow-2xl border border-input p-6 sm:p-10">
        {/* Header */}
        <div className="flex items-center gap-3 border-b border-input pb-6 mb-8">
          <img src="/images/design-mode/Medical%20logo.png" alt="Vitalis Medical" className="object-contain py-0 border-0 w-28 h-28" />
          <div>
            <h1 className="text-3xl font-bold text-foreground">Vitalis DID Wallet</h1>
            <p className="text-sm text-muted-foreground mt-1">Secure DID & Encrypted Health Data Storage</p>
          </div>
        </div>

        {/* Step Indicators */}
        <div className="flex justify-between mb-10 border-b border-input/50 pb-6 overflow-x-auto gap-4">
          {steps.map((step, index) => (
            <div key={index} className="flex-shrink-0">
              <StepIndicator step={index + 1} currentStep={currentStep} title={step.title} />
            </div>
          ))}
        </div>

        {/* Current Step Content */}
        <div className="p-4 sm:p-6 bg-secondary/10 rounded-xl border border-input">
          {CurrentStepComponent && (
            <CurrentStepComponent onNext={handleNext} initialData={userData} userData={userData} />
          )}
        </div>
      </div>

      {/* Back Link */}
      <div className="absolute top-4 left-4">
        <a href="https://vitalismedical.vercel.app" target="_top">
          <Button variant="outline" className="gap-2 bg-transparent">
            <ArrowRight className="w-4 h-4 transform rotate-180" /> Back Home
          </Button>
        </a>
      </div>
    </div>
  )
}
