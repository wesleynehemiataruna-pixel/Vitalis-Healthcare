import { getServiceRoleClient } from "@/lib/supabase-client"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { walletAddress, publicKey, mnemonicHash } = body

    if (!walletAddress || !publicKey) {
      return NextResponse.json({ error: "Missing required wallet data" }, { status: 400 })
    }

    console.log("[v0] Creating wallet for address:", walletAddress.substring(0, 12) + "...")

    const serviceSupabase = await getServiceRoleClient()

    // Generate a proper UUID v4 for user_id
    const generateUUID = () => {
      return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
        const r = (Math.random() * 16) | 0
        const v = c === "x" ? r : (r & 0x3) | 0x8
        return v.toString(16)
      })
    }

    const userId = generateUUID()

    // Store wallet in database
    const { data, error } = await serviceSupabase
      .from("did_wallets")
      .insert([
        {
          user_id: userId,
          did_address: walletAddress,
          wallet_public_key: publicKey,
          recovery_phrase_hash: mnemonicHash || "no-hash",
          blockchain_network: "ethereum",
          wallet_type: "hierarchical-deterministic",
          is_active: true,
        },
      ])
      .select()

    if (error) {
      console.log("[v0] Wallet insert error:", error.message)
      throw error
    }

    console.log("[v0] Wallet created successfully:", data?.[0]?.id)

    // Log the wallet creation
    await serviceSupabase.from("wallet_access_logs").insert([
      {
        user_id: userId,
        did_address: walletAddress,
        action: "WALLET_CREATED",
        status: "SUCCESS",
        access_timestamp: new Date().toISOString(),
      },
    ])

    return NextResponse.json({
      success: true,
      wallet: data?.[0],
      userId: userId,
    })
  } catch (error) {
    console.error("[v0] Wallet creation error:", error)
    return NextResponse.json({ error: error.message || "Failed to create wallet" }, { status: 500 })
  }
}
