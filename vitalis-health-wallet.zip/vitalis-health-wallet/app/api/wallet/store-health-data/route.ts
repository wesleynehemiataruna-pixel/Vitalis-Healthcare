import { getServiceRoleClient } from "@/lib/supabase-client"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    console.log("[v0] Store health data API called")

    const body = await request.json()
    const {
      bloodType,
      allergies,
      medicalConditions,
      currentMedications,
      emergencyContact,
      encryptedData,
      dataHash,
      didAddress,
      userId,
      fullName,
      dateOfBirth,
    } = body

    if (!encryptedData || !didAddress) {
      console.log("[v0] Missing required fields: encryptedData or didAddress")
      return NextResponse.json({ error: "Missing encrypted data or DID address" }, { status: 400 })
    }

    console.log("[v0] Storing health record for DID:", didAddress.substring(0, 12) + "...")

    const serviceSupabase = await getServiceRoleClient()

    const { data: wallet, error: walletError } = await serviceSupabase
      .from("did_wallets")
      .select("user_id")
      .eq("did_address", didAddress)
      .maybeSingle()

    if (walletError) {
      console.log("[v0] Wallet lookup error:", walletError.message)
    }

    const generateUUID = () => {
      return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
        const r = (Math.random() * 16) | 0
        const v = c === "x" ? r : (r & 0x3) | 0x8
        return v.toString(16)
      })
    }

    const finalUserId = userId || wallet?.user_id || generateUUID()

    console.log("[v0] Storing health record with userId:", finalUserId)

    // Store encrypted health record using service role
    const { data, error } = await serviceSupabase
      .from("encrypted_health_records")
      .insert([
        {
          user_id: finalUserId,
          did_address: didAddress,
          full_name: fullName || null,
          date_of_birth: dateOfBirth || null,
          blood_type: bloodType || null,
          allergies: allergies || null,
          medical_conditions: medicalConditions || null,
          current_medications: currentMedications || null,
          emergency_contact: emergencyContact || null,
          encrypted_data: encryptedData,
          data_hash: dataHash || null,
          record_status: "ENCRYPTED_STORED",
          encryption_method: "DID-AES-256",
          blockchain_tx_hash: `0x${Math.random().toString(16).substring(2, 66)}`,
          blockchain_timestamp: new Date().toISOString(),
        },
      ])
      .select()

    if (error) {
      console.log("[v0] Insert error:", error.message, error.details, error.code)
      throw error
    }

    console.log("[v0] Health record inserted successfully:", data?.[0]?.id)

    // Log the health data storage
    await serviceSupabase.from("wallet_access_logs").insert([
      {
        user_id: finalUserId,
        did_address: didAddress,
        action: "HEALTH_DATA_STORED",
        status: "SUCCESS",
        access_timestamp: new Date().toISOString(),
      },
    ])

    return NextResponse.json({
      success: true,
      record: data?.[0],
      recordId: data?.[0]?.id,
    })
  } catch (error) {
    console.error("[v0] Health data storage error:", error)
    return NextResponse.json({ error: error.message || "Failed to store health data" }, { status: 500 })
  }
}
