import { getBrowserClient } from "./supabase-client"

export interface DIDWallet {
  id: string
  user_id: string
  did_address: string
  wallet_public_key: string
  created_at: string
}

export interface HealthRecord {
  id: string
  user_id: string
  did_address: string
  blood_type: string
  allergies: string
  medical_conditions: string
  current_medications: string
  encrypted_data: string
  encryption_method: string
  record_status: string
}

// Store DID wallet to database
export async function storeDIDWallet(
  userId: string,
  wallet: {
    address: string
    publicKey: string
    mnemonicHash: string
  },
) {
  const supabase = getBrowserClient()

  const { data, error } = await supabase
    .from("did_wallets")
    .insert([
      {
        user_id: userId,
        did_address: wallet.address,
        wallet_public_key: wallet.publicKey,
        recovery_phrase_hash: wallet.mnemonicHash,
      },
    ])
    .select()

  if (error) throw error
  return data?.[0]
}

// Store encrypted health records
export async function storeHealthRecord(
  userId: string,
  wallet: DIDWallet,
  healthData: {
    blood_type: string
    allergies: string
    medical_conditions: string
    current_medications: string
    emergency_contact: string
    encrypted_data: string
    data_hash: string
  },
) {
  const supabase = getBrowserClient()

  const { data, error } = await supabase
    .from("encrypted_health_records")
    .insert([
      {
        user_id: userId,
        did_address: wallet.did_address,
        blood_type: healthData.blood_type,
        allergies: healthData.allergies,
        medical_conditions: healthData.medical_conditions,
        current_medications: healthData.current_medications,
        emergency_contact: healthData.emergency_contact,
        encrypted_data: healthData.encrypted_data,
        data_hash: healthData.data_hash,
        record_status: "ENCRYPTED_STORED",
      },
    ])
    .select()

  if (error) throw error
  return data?.[0]
}

// Get user's DID wallet
export async function getUserDIDWallet(userId: string): Promise<DIDWallet | null> {
  const supabase = getBrowserClient()

  const { data, error } = await supabase.from("did_wallets").select("*").eq("user_id", userId).single()

  if (error) return null
  return data
}

// Get user's health records
export async function getUserHealthRecords(userId: string) {
  const supabase = getBrowserClient()

  const { data, error } = await supabase
    .from("encrypted_health_records")
    .select("*")
    .eq("user_id", userId)
    .order("created_at", { ascending: false })

  if (error) throw error
  return data
}

// Log wallet access
export async function logWalletAccess(userId: string, didAddress: string, action: string) {
  const supabase = getBrowserClient()

  await supabase.from("wallet_access_logs").insert([
    {
      user_id: userId,
      did_address: didAddress,
      action,
      status: "SUCCESS",
    },
  ])
}
