-- Add full_name and date_of_birth columns to encrypted_health_records table
ALTER TABLE encrypted_health_records
ADD COLUMN IF NOT EXISTS full_name character varying,
ADD COLUMN IF NOT EXISTS date_of_birth date;

-- Add comment describing the new columns
COMMENT ON COLUMN encrypted_health_records.full_name IS 'User full legal name';
COMMENT ON COLUMN encrypted_health_records.date_of_birth IS 'User date of birth';

-- Create index on full_name for faster searches
CREATE INDEX IF NOT EXISTS idx_encrypted_health_records_full_name 
ON encrypted_health_records(full_name);

-- Create index on date_of_birth for faster searches
CREATE INDEX IF NOT EXISTS idx_encrypted_health_records_dob 
ON encrypted_health_records(date_of_birth);
