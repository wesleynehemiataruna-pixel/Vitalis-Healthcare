-- Update RLS policies to allow unauthenticated users to store health data during signup
-- This allows users to create wallets and store health data before email confirmation

-- Drop existing restrictive policies
DROP POLICY IF EXISTS "Users can insert their own wallet" ON did_wallets;
DROP POLICY IF EXISTS "Users can insert their own health records" ON encrypted_health_records;
DROP POLICY IF EXISTS "Users can insert their own profile" ON user_profiles;

-- New policies that allow public inserts (for signup flow)
CREATE POLICY "Allow public to insert wallet"
  ON did_wallets FOR INSERT
  WITH CHECK (TRUE);

CREATE POLICY "Allow public to view own wallet by did_address"
  ON did_wallets FOR SELECT
  USING (TRUE);

-- Health records - allow public inserts
CREATE POLICY "Allow public to insert health records"
  ON encrypted_health_records FOR INSERT
  WITH CHECK (TRUE);

CREATE POLICY "Allow public to view health records"
  ON encrypted_health_records FOR SELECT
  USING (TRUE);

-- User profiles - allow public inserts
CREATE POLICY "Allow public to insert profile"
  ON user_profiles FOR INSERT
  WITH CHECK (TRUE);

CREATE POLICY "Allow public to view profile"
  ON user_profiles FOR SELECT
  USING (TRUE);

-- Keep authenticated user policies for existing users
CREATE POLICY "Authenticated users can view their own wallet"
  ON did_wallets FOR SELECT
  USING (auth.uid() = user_id OR auth.uid() IS NULL);

CREATE POLICY "Authenticated users can view their own health records"
  ON encrypted_health_records FOR SELECT
  USING (auth.uid() = user_id OR auth.uid() IS NULL);

CREATE POLICY "Authenticated users can view their own profile"
  ON user_profiles FOR SELECT
  USING (auth.uid() = user_id OR auth.uid() IS NULL);
