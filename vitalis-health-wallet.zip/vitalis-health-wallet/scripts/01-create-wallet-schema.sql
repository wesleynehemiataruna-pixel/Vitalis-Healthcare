-- Create DID Wallets table
CREATE TABLE IF NOT EXISTS did_wallets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL UNIQUE,
  did_address VARCHAR(255) NOT NULL UNIQUE,
  wallet_public_key TEXT NOT NULL,
  recovery_phrase_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  is_active BOOLEAN DEFAULT TRUE,
  blockchain_network VARCHAR(50) DEFAULT 'ethereum',
  wallet_type VARCHAR(50) DEFAULT 'hierarchical-deterministic'
);

-- Create User Profiles table
CREATE TABLE IF NOT EXISTS user_profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL UNIQUE REFERENCES did_wallets(user_id),
  full_name VARCHAR(255),
  email VARCHAR(255) NOT NULL UNIQUE,
  phone VARCHAR(20),
  date_of_birth DATE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create Encrypted Health Data table (Blockchain-compatible)
CREATE TABLE IF NOT EXISTS encrypted_health_records (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES did_wallets(user_id),
  did_address VARCHAR(255) NOT NULL REFERENCES did_wallets(did_address),
  blood_type VARCHAR(5),
  allergies TEXT,
  medical_conditions TEXT,
  current_medications TEXT,
  emergency_contact VARCHAR(255),
  encrypted_data TEXT NOT NULL,
  data_hash VARCHAR(255),
  encryption_method VARCHAR(50) DEFAULT 'DID-AES-256',
  record_status VARCHAR(50) DEFAULT 'ENCRYPTED_STORED',
  blockchain_tx_hash VARCHAR(255),
  blockchain_timestamp TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create Wallet Access Logs table (for audit trail)
CREATE TABLE IF NOT EXISTS wallet_access_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES did_wallets(user_id),
  did_address VARCHAR(255) NOT NULL,
  action VARCHAR(100),
  access_timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  ip_address INET,
  status VARCHAR(50)
);

-- Enable RLS (Row Level Security)
ALTER TABLE did_wallets ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE encrypted_health_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE wallet_access_logs ENABLE ROW LEVEL SECURITY;

-- RLS Policies for did_wallets
CREATE POLICY "Users can view their own wallet"
  ON did_wallets FOR SELECT
  USING (user_id = auth.uid());

CREATE POLICY "Users can insert their own wallet"
  ON did_wallets FOR INSERT
  WITH CHECK (user_id = auth.uid());

-- RLS Policies for user_profiles
CREATE POLICY "Users can view their own profile"
  ON user_profiles FOR SELECT
  USING (user_id = auth.uid());

CREATE POLICY "Users can update their own profile"
  ON user_profiles FOR UPDATE
  USING (user_id = auth.uid());

CREATE POLICY "Users can insert their own profile"
  ON user_profiles FOR INSERT
  WITH CHECK (user_id = auth.uid());

-- RLS Policies for encrypted_health_records
CREATE POLICY "Users can view their own health records"
  ON encrypted_health_records FOR SELECT
  USING (user_id = auth.uid());

CREATE POLICY "Users can insert their own health records"
  ON encrypted_health_records FOR INSERT
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update their own health records"
  ON encrypted_health_records FOR UPDATE
  USING (user_id = auth.uid());

-- RLS Policies for wallet_access_logs
CREATE POLICY "Users can view their own access logs"
  ON wallet_access_logs FOR SELECT
  USING (user_id = auth.uid());

CREATE POLICY "System can insert access logs"
  ON wallet_access_logs FOR INSERT
  WITH CHECK (TRUE);

-- Create indexes for performance
CREATE INDEX idx_did_wallets_user_id ON did_wallets(user_id);
CREATE INDEX idx_did_wallets_did_address ON did_wallets(did_address);
CREATE INDEX idx_user_profiles_user_id ON user_profiles(user_id);
CREATE INDEX idx_health_records_user_id ON encrypted_health_records(user_id);
CREATE INDEX idx_health_records_did_address ON encrypted_health_records(did_address);
CREATE INDEX idx_access_logs_user_id ON wallet_access_logs(user_id);

-- Add comments for documentation
COMMENT ON TABLE did_wallets IS 'Stores decentralized identity (DID) wallet information and blockchain addresses';
COMMENT ON TABLE encrypted_health_records IS 'Stores encrypted health data linked to DID wallets for blockchain storage';
COMMENT ON TABLE wallet_access_logs IS 'Audit trail for wallet access and transactions';
